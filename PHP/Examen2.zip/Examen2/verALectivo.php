<?php
include("conexion2.php");
	if(!$bdcon)
	{
		echo "Lo sentimos, este sitio web esta experimentando problemas";
		exit;
	}
	else 
	{
		$datos=array();
    	$sql="SELECT his.alumno_rne,alu.alumno_nombre1, alu.alumno_ape1, alu.alumno_genero, grade.grado_nombre 
            FROM `tbl_historial` as his 
            INNER JOIN tbl_alumno as alu on alu.alumno_rne = his.alumno_rne
            INNER JOIN tbl_grado as grade on grade.grado_codigo = his.grado_codigo
            WHERE his.aniol_anio =".$_GET["alectivo"];
    	
		$result=mysqli_query($conexion,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			array_push($datos,array(
			    'alumno_rne'=>$row["alumno_rne"],
				'alumno_nombre1'=>$row["alumno_nombre1"],
				'alumno_ape1'=>$row["alumno_ape1"],
				'alumno_genero'=>$row["alumno_genero"],
				'grado_nombre'=>$row["grado_nombre"],
			));
		}
		echo utf8_encode(json_encode($datos));
	}
?>