<?php 
    $bdcon=true;
	$conexion=new mysqli("localhost","id17969292_camilo15","Molina__0225","id17969292_examenmovil");
	if($conexion->connect_errno)
	{
		$bdcon=false;
		echo "Lo sentimos, este sitio web esta experimentando problemas ".$mysqli -> error;
		//exit;

	}
	
?>