<?php
include("conexion.php");
	if(!$bdcon)
	{
		echo "Lo sentimos, este sitio web esta experimentando problemas";
		exit;
	}
	else 
	{
		$datos=array();
		$sql="select * from tbl_user";
		$result=mysqli_query($conexion,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			array_push($datos,array(
				'user'=>$row["usuario_codigo"],
				'estado'=>$row["usuario_estado"],
			));
		}
		echo utf8_encode(json_encode($datos));
	}
?>