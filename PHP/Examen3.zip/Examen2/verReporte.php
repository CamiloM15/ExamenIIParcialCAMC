<?php
include("conexion2.php");
	if(!$bdcon)
	{
		echo "Lo sentimos, este sitio web esta experimentando problemas";
		exit;
	}
	else 
	{
		$datos=array();
    	$sql="SELECT al.alumno_rne, al.alumno_nombre1, al.alumno_ape1, al.alumno_genero, al.alumno_fnac, hi.aniol_anio, gra.grado_nombre, pa.idParentezco, pa.nombreParentezco, pa.TelefonoParentezco, tipo.tipoParentesco 
            From tbl_alumno as al INNER JOIN tbl_historial as hi on hi.alumno_rne = al.alumno_rne
					  INNER JOIN parentezco as pa on pa.alumno_rne = al.alumno_rne
                      INNER JOIN tbl_grado as gra on gra.grado_codigo = hi.grado_codigo
                      INNER JOIN tipoParentesco as tipo on tipo.idTipo = pa.idTipo
            WHERE al.alumno_rne =".$_GET["rne"];
    	
		$result=mysqli_query($conexion,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			array_push($datos,array(
			    'alumno_rne'=>$row["alumno_rne"],
				'alumno_nombre1'=>$row["alumno_nombre1"],
				'alumno_ape1'=>$row["alumno_ape1"],
				'alumno_genero'=>$row["alumno_genero"],
				'alumno_fnac'=>$row["alumno_fnac"],
				'aniol_anio'=>$row["aniol_anio"],
				'grado_nombre'=>$row["grado_nombre"],
				'idParentezco'=>$row["idParentezco"],
				'nombreParentezco'=>$row["nombreParentezco"],
				'TelefonoParentezco'=>$row["TelefonoParentezco"],
				'tipoParentesco'=>$row["tipoParentesco"]
			));
		}
		echo utf8_encode(json_encode($datos));
	}
?>