<?php 
	include("conexion2.php");
	if(!$bdcon)
	{
		echo "Lo sentimos, este sitio web esta experimentando problemas";
		exit;
	}
	else 
	{
		$idParentezco=$_POST["idParentezco"];
		$nombreParentezco=$_POST["nombreParentezco"];
		$TelefonoParentezco=$_POST["TelefonoParentezco"];
		$direccion=$_POST["direccion"];
		$idTipo=$_POST["idTipo"];
		$alumno_rne=$_POST["alumno_rne"];
		$consulta="INSERT INTO `parentezco`(`idParentezco`, `nombreParentezco`, `TelefonoParentezco`, `direccion`, `idTipo`, `alumno_rne`) VALUES ('".$idParentezco."','".$nombreParentezco."','".$TelefonoParentezco."','".$direccion."','".$idTipo."','".$alumno_rne."')";
		if(mysqli_query($conexion,$consulta))
		{
			echo "1";
		}
		else 
		{
		    echo "0";
		}
	}
?>