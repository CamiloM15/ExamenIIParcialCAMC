<?php
include("conexion2.php");
	if(!$bdcon)
	{
		echo "Lo sentimos, este sitio web esta experimentando problemas";
		exit;
	}
	else 
	{
		$datos=array();
		$sql="SELECT * FROM tipoParentesco";
		$result=mysqli_query($conexion,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			array_push($datos,array(
				'idTipo'=>$row["idTipo"],
				'tipoParentesco'=>$row["tipoParentesco"],
			));
		}
		echo utf8_encode(json_encode($datos));
	}
?>